"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.fetchPosts = undefined;

var _regenerator = require("babel-runtime/regenerator");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _index = require("./utils/index");

var _reddit = require("./reddit.schema");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator.throw(value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : new P(function (resolve) {
                resolve(result.value);
            }).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
var fetchPosts = exports.fetchPosts = function fetchPosts(reddit) {
    return __awaiter(undefined, void 0, void 0, _regenerator2.default.mark(function _callee() {
        var json;
        return _regenerator2.default.wrap(function _callee$(_context) {
            while (1) {
                switch (_context.prev = _context.next) {
                    case 0:
                        _context.prev = 0;
                        _context.t0 = _reddit.fetchPostsSchema;
                        _context.next = 4;
                        return (0, _index.get)("/r/" + reddit + ".json").end();

                    case 4:
                        _context.t1 = _context.sent;
                        json = (0, _index.validate)(_context.t0, _context.t1);
                        return _context.abrupt("return", json.data.children.map(function (child) {
                            return child.data;
                        }));

                    case 9:
                        _context.prev = 9;
                        _context.t2 = _context["catch"](0);
                        throw _context.t2;

                    case 12:
                    case "end":
                        return _context.stop();
                }
            }
        }, _callee, this, [[0, 9]]);
    }));
};