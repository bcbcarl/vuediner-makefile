"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.reddit = undefined;

var _reddit = require("./reddit");

var reddit = exports.reddit = { fetchPosts: _reddit.fetchPosts };