"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.validate = exports.del = exports.patch = exports.post = exports.get = undefined;

var _agent = require("./agent");

var _agent2 = _interopRequireDefault(_agent);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var validator = require("is-my-json-valid");
var baseUrl = "http://www.reddit.com";
var get = exports.get = function get(url) {
    var request = new _agent2.default(baseUrl);
    return request.get(url).withCredentials();
};
var post = exports.post = function post(url) {
    var request = new _agent2.default(baseUrl);
    return request.post(url).withCredentials();
};
var patch = exports.patch = function patch(url) {
    var request = new _agent2.default(baseUrl);
    return request.patch(url).withCredentials();
};
var del = exports.del = function del(url) {
    var request = new _agent2.default(baseUrl);
    return request.del(url).withCredentials();
};
var validate = exports.validate = function validate(schema, data) {
    var validateFn = validator(schema);
    if (!validateFn(data)) {
        var error = validateFn.errors[0];
        throw new TypeError("`" + error.field + "` " + error.message);
    }
    return data;
};