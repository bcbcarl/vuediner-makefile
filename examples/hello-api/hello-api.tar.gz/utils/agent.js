"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = require("babel-runtime/helpers/createClass");

var _createClass3 = _interopRequireDefault(_createClass2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var qs = require("qs");
var contains = function contains(value, list) {
    return list.some(function (x) {
        return x === value;
    });
};
var isPlainObject = function isPlainObject(value) {
    return Object.prototype.toString.call(value) === "[object Object]";
};

var Agent = function () {
    function Agent(baseUrl) {
        (0, _classCallCheck3.default)(this, Agent);

        this.url = baseUrl;
        this.method = "GET";
        this.contentType = "application/json";
        this.headers = {};
        this.queryObj = {};
        this.response = {};
    }

    (0, _createClass3.default)(Agent, [{
        key: "get",
        value: function get(url) {
            this.method = "GET";
            this.url += url;
            return this;
        }
    }, {
        key: "post",
        value: function post(url) {
            this.method = "POST";
            this.url += url;
            return this;
        }
    }, {
        key: "put",
        value: function put(url) {
            this.method = "PUT";
            this.url += url;
            return this;
        }
    }, {
        key: "patch",
        value: function patch(url) {
            this.method = "PATCH";
            this.url += url;
            return this;
        }
    }, {
        key: "del",
        value: function del(url) {
            this.method = "DELETE";
            this.url += url;
            return this;
        }
    }, {
        key: "withCredentials",
        value: function withCredentials() {
            var credentials = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "same-origin";

            this.credentials = credentials;
            return this;
        }
    }, {
        key: "type",
        value: function type(contentType) {
            var types = {
                json: "application/json",
                form: "application/x-www-form-urlencoded"
            };
            this.contentType = types[contentType] || contentType;
            return this;
        }
    }, {
        key: "query",
        value: function query(obj) {
            this.queryObj = Object.assign({}, this.queryObj, obj);
            return this;
        }
    }, {
        key: "attach",
        value: function attach(field, file, filename) {
            this.contentType = "multipart/form-data";
            this.formData = new FormData();
            this.formData.append(field, file, filename || file.name);
            return this;
        }
    }, {
        key: "send",
        value: function send(data) {
            if (!isPlainObject(data)) {
                throw new Error("Data MUST be an object.");
            }
            if (!contains(this.method, ["POST", "PUT", "PATCH"])) {
                throw new Error("Method " + this.method + " is not allowed. You MUST send a \"POST\", \"PUT\", or \"PATCH\" request.");
            }
            if (!Object.keys(data).length) {
                return this;
            }
            // auto-detect attachment content-type
            if (this.contentType !== "multipart/form-data") {
                this.setContentType(this.contentType);
            }
            this.setBody(this.contentType, data);
            return this;
        }
    }, {
        key: "setContentType",
        value: function setContentType(contentType) {
            this.headers["Content-Type"] = contentType;
        }
    }, {
        key: "getContentType",
        value: function getContentType() {
            return this.contentType;
        }
    }, {
        key: "setBody",
        value: function setBody(contentType, data) {
            var _this = this;

            var serialize = {
                "application/json": JSON.stringify,
                "application/x-www-form-urlencoded": qs.stringify,
                "multipart/form-data": function multipartFormData(obj) {
                    return Object.keys(obj).reduce(function (f, k) {
                        return f.append(k, obj[k]), f;
                    }, _this.formData);
                }
            };
            var f = serialize[this.contentType];
            this.body = f ? f(data) : data;
        }
    }, {
        key: "getBody",
        value: function getBody(contentType, data) {
            return this.body;
        }
    }, {
        key: "getUrl",
        value: function getUrl() {
            return Object.keys(this.queryObj).length > 0 ? this.url + "?" + qs.stringify(this.queryObj) : this.url;
        }
    }, {
        key: "end",
        value: function end(callback) {
            var fetchParams = {
                method: this.method,
                headers: this.headers
            };
            if (this.body) {
                fetchParams.body = this.body;
            }
            if (this.credentials) {
                fetchParams.credentials = this.credentials;
            }
            var promise = fetch(this.getUrl(), fetchParams).then(function (res) {
                return res.json();
            });
            return callback ? promise.then(callback) : promise;
        }
    }, {
        key: "then",
        value: function then(resolve, reject) {
            return this.end().then(resolve, reject);
        }
    }]);
    return Agent;
}();

exports.default = Agent;